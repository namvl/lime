import Layout from "../components/Layout"

//src/pages/Home.tsx
export const Home = () => {
    return (
        <Layout>
          <h1>This is home page</h1>
        </Layout>
      )
  }